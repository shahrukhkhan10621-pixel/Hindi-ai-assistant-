[app]
title = Hindi English AI Assistant
package.name = voiceassistant
package.domain = org.example
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0
requirements = python3,kivy,openai
orientation = portrait
fullscreen = 0

android.permissions = INTERNET,RECORD_AUDIO
android.api = 35
android.minapi = 23

[buildozer]
log_level = 2
warn_on_root = 1
