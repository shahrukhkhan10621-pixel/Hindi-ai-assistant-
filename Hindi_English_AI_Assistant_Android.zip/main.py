import os
import threading
from openai import OpenAI
from kivy.app import App
from kivy.clock import Clock
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

SYSTEM = """You are a helpful Hindi-English voice assistant.
Reply naturally and concisely. The user may speak Hindi, Hinglish, or English."""

class AssistantUI(BoxLayout):
    status = StringProperty("Ready")

    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=20, spacing=12, **kwargs)
        self.history = []
        self.client = None

        self.output = Label(text="Namaste! Main ready hoon. Boliye.",
                            halign="left", valign="top")
        self.add_widget(self.output)

        self.input = TextInput(hint_text="Yahan type karein...", multiline=False,
                               size_hint_y=None, height=55)
        self.add_widget(self.input)

        row = BoxLayout(size_hint_y=None, height=55, spacing=10)
        send = Button(text="Send")
        send.bind(on_release=lambda *_: self.send_text())
        row.add_widget(send)

        listen = Button(text="🎙️ Speak")
        listen.bind(on_release=lambda *_: self.start_voice())
        row.add_widget(listen)
        self.add_widget(row)

        self.status_label = Label(text=self.status, size_hint_y=None, height=35)
        self.add_widget(self.status_label)

        self.input.bind(text=lambda *_: setattr(self.status_label, "text", self.status))

        # On Android, use an environment variable supplied at build/run time.
        key = os.getenv("OPENAI_API_KEY")
        if key:
            self.client = OpenAI(api_key=key)

    def show(self, text):
        self.output.text = text

    def send_text(self):
        text = self.input.text.strip()
        if not text:
            return
        self.input.text = ""
        self.ask_async(text)

    def ask_async(self, text):
        if not self.client:
            self.show("OPENAI_API_KEY set nahi hai. App ko API key ke saath configure karein.")
            return
        self.status = "AI soch raha hai..."
        self.status_label.text = self.status
        threading.Thread(target=self._ask, args=(text,), daemon=True).start()

    def _ask(self, text):
        try:
            self.history.append({"role": "user", "content": text})
            response = self.client.responses.create(
                model="gpt-5.6-luna",
                instructions=SYSTEM,
                input=self.history,
                store=False,
            )
            answer = response.output_text.strip()
            self.history.append({"role": "assistant", "content": answer})
            Clock.schedule_once(lambda dt: self.finish(answer), 0)
        except Exception as e:
            Clock.schedule_once(lambda dt: self.finish("AI se connect nahi ho paaya: " + str(e)), 0)

    def finish(self, answer):
        self.show(answer)
        self.status = "Ready"
        self.status_label.text = self.status

    def start_voice(self):
        try:
            from android import activity
            from android.content import Intent
            from android.speech import RecognizerIntent

            intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye...")
            activity.startActivityForResult(intent, 9001)
            self.status = "Sun raha hoon..."
            self.status_label.text = self.status
        except Exception as e:
            self.show("Voice input available nahi hai: " + str(e))

class VoiceAssistantApp(App):
    def build(self):
        return AssistantUI()

if __name__ == "__main__":
    VoiceAssistantApp().run()
